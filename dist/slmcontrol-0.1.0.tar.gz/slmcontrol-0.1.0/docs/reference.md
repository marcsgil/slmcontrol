# Reference

This page contains a detailed description of all exported methods.

## Structures

::: src.slmcontrol.structures

## Zernike Polynomials
::: src.slmcontrol.zernike

## Hologram

::: src.slmcontrol.hologram   

## SLM

::: src.slmcontrol.slm
    options:
        filters: ["!videoThread"]